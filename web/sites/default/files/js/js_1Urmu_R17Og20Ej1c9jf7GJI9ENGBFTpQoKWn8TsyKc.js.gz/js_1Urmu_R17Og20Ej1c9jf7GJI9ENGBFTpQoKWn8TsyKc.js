new Vue({
  el: '.hotels-block',
  template: '<div class="test">{{ message }}</div>',
  data: {
    message: 'Hello Vue! This will only work on a single Example 1 block per page.'
  }
});;
